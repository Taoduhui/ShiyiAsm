import { PageData } from "@ShiyiFramework/ShiyiPage/Base/ShiyiPageBase";

export interface {{ShiyiAsm:Templete}}Data extends PageData{

}