import { {{ShiyiAsm:Templete}} } from "../{{ShiyiAsm:Templete}}";
import { ShiyiPageFuncBase } from "@ShiyiFramework/ShiyiPage/Base/ShiyiPageBase";

export class {{ShiyiAsm:Templete}}Func<PageT extends {{ShiyiAsm:Templete}}> extends ShiyiPageFuncBase<PageT>{

    public InitCustomData(_options?: Record<string, any>): void {
    }
}