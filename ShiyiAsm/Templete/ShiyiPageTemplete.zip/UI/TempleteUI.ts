import { {{ShiyiAsm:Templete}} } from "../{{ShiyiAsm:Templete}}";
import { ShiyiPageUIBase } from "@ShiyiFramework/ShiyiPage/Base/ShiyiPageBase";


export class {{ShiyiAsm:Templete}}UI extends ShiyiPageUIBase<{{ShiyiAsm:Templete}}> {

    public InitCustomData(_options?: Record<string, any>): void {
    }
}