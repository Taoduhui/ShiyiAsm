import { PesudoCompnent } from "@Root/ShiyiFramework/ShiyiPesudoCompnent/PesudoCompnent";
import { {{ShiyiAsm:Templete}}CompData } from "./Model/Model";

export class {{ShiyiAsm:Templete}} extends PesudoCompnent{
    public data:{{ShiyiAsm:Templete}}CompData={
        Theme: "",
    }
}