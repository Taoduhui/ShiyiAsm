import { PesudoCompnentData } from "@Root/ShiyiFramework/ShiyiPesudoCompnent/PesudoCompnent";

export interface {{ShiyiAsm:Templete}}CompData extends PesudoCompnentData{
}