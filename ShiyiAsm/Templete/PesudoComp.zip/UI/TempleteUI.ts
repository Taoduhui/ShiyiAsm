
import { ShiyiCompUIBase } from "@Root/ShiyiFramework/ShiyiPesudoCompnent/PesudoCompnent";
import { {{ShiyiAsm:Templete}} } from "../{{ShiyiAsm:Templete}}";


export class {{ShiyiAsm:Templete}}UI<CompT extends {{ShiyiAsm:Templete}}> extends ShiyiCompUIBase<CompT> {

    public InitCustomData(_options?: Record<string, any>): void {

    }
}