import { ShiyiCompFuncBase } from "@Root/ShiyiFramework/ShiyiPesudoCompnent/PesudoCompnent";
import { {{ShiyiAsm:Templete}} } from "../{{ShiyiAsm:Templete}}";

export class {{ShiyiAsm:Templete}}Func<CompT extends {{ShiyiAsm:Templete}}> extends ShiyiCompFuncBase<CompT>{

    public InitCustomData(_options?: Record<string, any>): void {

    }
}